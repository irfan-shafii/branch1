
<header class="panel-heading wht-bg">
   <h4 class="gen-case"> 
	<a href="#"  class="btn btn-round btn-success">
	Incoming Call
	</a> <a href="#"  class="btn btn-round btn-default">
	Outgoing Call
	</a>
	<span><a href="#"  class="btn btn-info pull-right">
        Campaign Id - Details
    </a></span>
        <!-- <div class="input-append">
            <input type="text" class="form-control " maxlength="8" placeholder="Search Phone"  onkeydown="searchph(this)">
        </div> -->
   </h4>
</header>
<div class="row">

<div class="col-lg-4">
<section class="panel">

<div class="prf-box">
<h3 class="prf-border-head">
Customers
</h3>
</header>
<ul class="nav nav-pills nav-stacked">
@foreach($mktargt as $acc)
<li class="acclist" id="acclist{{$acc->MAGIC}}"><a class="ex2" href="#" onclick="customerinfo('{{$acc->MAGIC}}');"> <i class="fa fa-user"></i> {{$acc->FIRSTNAM}} {{$acc->SURNAME}}</a></li>
@endforeach

</ul>

</div>
</section>
</div>


<div class="col-lg-4">
<section class="panel">

<div class="prf-box">
<h3 class="prf-border-head">
vehicles
</h3>

<ul class="nav nav-pills nav-stacked" id="vehicle_list">
</ul>

</div>
</section>
</div>


<div class="col-lg-4">

<section class="panel">
<div class="panel-body">

<div class="input-group m-bot15">
<input type="text" class="form-control" placeholder="Search Mobile Number" id="phsearch">
<span class="input-group-btn">
<button class="btn btn-success" type="enter" onclick="search();">Search</button>
</span>
</div>

</div>
</section>


@if(count($upscales) > 0)
<!--carousel start-->
<section class="panel">
<div id="c-slide" class="carousel slide panel-body" data-ride="carousel">
<ol class="carousel-indicators out">
<?php for($i=0; $i<count($upscales); $i++ ) {
if($i == '0'){
$rowclass = 'active';
}
else{
$rowclass = '';
} ?>
<li class="{{$rowclass}}" data-slide-to="{{$i}}" data-target="#c-slide"></li>
<?php } $rowcount=0; ?>
</ol>
<div class="carousel-inner">
@foreach($upscales as $upscale)
<?php
if($rowcount == '0'){
$rowclass1 = 'active';
}
else{
$rowclass1 = '';
} ?>
<div class="item text-center {{$rowclass1}}">
<h3 style="color: #fa8564;">{{$upscale->topic}}</h3>
<p style="color: #95b75d;">{{$upscale->description}}</p>
</div>
<?php $rowcount++; ?>
@endforeach
</div>
<a data-slide="prev" href="{{asset('/bucket')}}/#c-slide" class="left carousel-control">
<i class="fa fa-angle-left"></i>
</a>
<a data-slide="next" href="{{asset('/bucket')}}/#c-slide" class="right carousel-control">
<i class="fa fa-angle-right"></i>
</a>
</div>
</section>
<!--carousel end-->
@endif
</div>

</div>


<div class="row">
<div class="col-lg-4">

<section class="panel">
<form action="{{url('/')}}/customer/store" method="post">
{{csrf_field()}}
<div class="prf-box">
        <h3 class="prf-border-head">Customer Info</h3>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">First Name</label>
<input type="text" class="form-control" name="fname" id="fname" value="{{$fname}}" placeholder="Enter First Name" required="">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Last Name</label>
<input type="text" class="form-control" name="lname" id="lname" value="{{$lname}}" placeholder="Enter Last Name">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Mobile Number</label>
<input type="number" class="form-control" name="mobile" id="mobile" value="{{$mobile}}" placeholder="Enter Mobile Number" required="">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Alternative Mobile</label>
<input type="number" class="form-control" name="mobile2" id="mobile2" value="{{$mobile2}}" placeholder="Enter Alternative Mobile">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Civil ID</label>
<input type="text" class="form-control" name="civilid" id="civilid" value="{{$civilid}}" placeholder="Enter Civil ID">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Gender</label>
<select class="form-control m-bot15" name="gender" id="gender">
<option value="">Select</option>
<option @if($gender == 'Male') selected="" @endif value="Male">Male</option>
<option @if($gender == 'Female') selected="" @endif value="Female">Female</option>
</select>
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Address</label>
<textarea type="text" class="form-control" name="address" id="address" placeholder="Enter Address">{{$address}}</textarea>
</div>
<input type="hidden" name="id_account" id="id_account" value="{{$id_account}}">
<input type="hidden" name="phone_number" id="phone_number" value="{{$mobile_number}}">
<input type="hidden" name="user_info" id="userid" value="{{$user_info}}">
<!-- <div class="form-group col-md-6">
<button type="submit" class="btn btn-danger">Save</button>
</div> -->

</div>

</form>
</section>
</div>

<div class="col-lg-4">
<section class="panel">
<div class="prf-box">
        <h3 class="prf-border-head">Vehicle Info</h3>                 
<form action="{{url('/')}}/customervehicle/store" method="post">
{{csrf_field()}}
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Vehicle Info</label>
<input type="text" class="form-control" name="vehicleinfo" id="vehicleinfo" value="" placeholder="Enter Vehicle Info">
</div>

<div class="form-group col-md-6">
<label for="exampleInputEmail1">Vehicle Model</label>
<input type="text" class="form-control" name="vehmodel" id="vehmodel" value="" placeholder="Enter Vehicle Model">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Vehicle Year</label>
<input type="text" class="form-control" name="vehyear" id="vehyear" value="" placeholder="Enter Vehicle Year">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Vehicle Colour</label>
<input type="text" class="form-control" name="vehcolor" id="vehcolor" value="" placeholder="Enter Vehicle Colour">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Vehicle Showroom</label>
<input type="text" class="form-control" name="vehshowroom" id="vehshowroom" value="" placeholder="Enter Vehicle Showroom">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Register Number</label>
<input type="text" class="form-control" name="plateno" id="plateno" value="" placeholder="Enter Vehicle Register Number">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Last Service Date</label>
<input type="text" class="form-control" name="lastservice" id="lastservice" value="" placeholder="Enter Vehicle Service Date">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Next Service Date</label>
<input type="text" class="form-control" name="nextservice" id="nextservice" value="" placeholder="Enter Vehicle Service Date">
</div>
<input type="hidden" name="vehid_account" id="vehid_account" value="{{$id_account}}">
<input type="hidden" name="vehicle_id" id="vehicle_id" value="0">
<input type="hidden" name="phone_number" id="phone_number" value="{{$mobile_number}}">
<input type="hidden" name="user_info" id="userid" value="{{$user_info}}">
<!-- <div class="form-group col-md-6">
<button type="submit" class="btn btn-danger">Save</button>
</div> -->
</div>
</form>
</section>

</div>

<div class="col-lg-4">
<section class="panel">
    <div class="prf-box">
        <h3 class="prf-border-head">QUICK SUMMARY - FOR SELECTED VEHICLE</h3>
        <div class=" wk-progress pf-status">
            <div class="col-md-8 col-xs-8">Total Calls - Dialed Today</div>
            <div class="col-md-4 col-xs-4">
                <strong>4</strong>
            </div>
        </div>
        <div class=" wk-progress pf-status">
            <div class="col-md-8 col-xs-8">Total Call Received Today</div>
            <div class="col-md-4 col-xs-4">
                <strong>2</strong>
            </div>
        </div>
        <div class=" wk-progress pf-status">
            <div class="col-md-8 col-xs-8">Total Campaign Calls Pending</div>
            <div class="col-md-4 col-xs-4">
                <strong>8</strong>
            </div>
        </div>
        <div class=" wk-progress pf-status">
            <div class="col-md-8 col-xs-8">Total Missed Calls</div>
            <div class="col-md-4 col-xs-4">
                <strong>1</strong>
            </div>
        </div>
    </div>
</section>

</div>
</div>


<div class="row">
<div class="col-lg-12">
<section class="panel">
<form action="{{url('/')}}/enquiry/store" method="post">
{{csrf_field()}}
<header class="panel-heading">
Enquiry Details
</header>
<div class="panel-body">
<div class="form-group col-md-3">
<label for="exampleInputEmail1">Enquiry Category</label>
<select class="form-control m-bot15" name="category" onChange="getcategory(this);" required="">
<option value="">Select</option>
@foreach($enquiry_categories as $category)
<option value="{{$category->id_enquiry_category}}">{{$category->category_name}}</option>
@endforeach
</select>
</div>
<div class="form-group col-md-3" id="subdiv1" style="display: none;">
<label for="exampleInputEmail1">Sub Category1</label>
<div id="subcatdiv1"></div>
</div>
<div class="form-group col-md-3" id="subdiv2" style="display: none;">
<label for="exampleInputEmail1">Sub Category2</label>
<div id="subcatdiv2"></div>
</div>
<div class="form-group col-md-3" id="subdiv3" style="display: none;">
<label for="exampleInputEmail1">Sub Category3</label>
<div id="subcatdiv3"></div>
</div>

<div id="agentDiv" style="display: none;">
<div class="form-group col-md-3">
<label for="exampleInputPassword1">Call Center Agent Name</label>
<input type="text" class="form-control" name="agentname" id="agentname" value="">
</div>
</div>
<div id="subtype1" style="display: none;">
<div class="form-group col-md-3">
<label for="exampleInputPassword1">Booked to Salesman</label>
<input type="text" class="form-control" name="salesman" id="salesman" value="">
</div>

<div class="form-group col-md-3">
<label for="exampleInputPassword1">Model Of Interest</label>
<input type="text" class="form-control" name="interest" id="interest" value="">
</div>

<div class="form-group col-md-3">
<label for="exampleInputPassword1">Type of Appoinment</label>
<input type="text" class="form-control" name="appointmenttype" id="appointmenttype" value="">
</div>

<div class="form-group col-md-3">
<label for="exampleInputPassword1">Showroom Name</label>
<input type="text" class="form-control" name="showroom" id="showroom" value="">
</div>
</div>

<div id="subtype2" style="display: none;">
<div class="form-group col-md-3">
<label for="exampleInputPassword1">Service Advisor Name</label>
<input type="text" class="form-control" name="advisorname" id="advisorname" value="">
</div>
<div class="form-group col-md-3">
<label for="exampleInputPassword1">Appointment Code</label>
<input type="text" class="form-control" name="appointmentcode" id="appointmentcode" value="">
</div>
</div>

<div class="form-group col-md-3" id="appointmentDiv" style="display: none;">
<label for="exampleInputPassword1">Appointment Date & Time</label>
<input size="16" type="text" value="" name="appointment" id="appointment" class="form_datetime form-control" autocomplete="off">
</div>

<div class="col-md-12"> </div>
<div class="form-group col-md-9">
<label for="exampleInputPassword1">Enquiry Description</label>
<textarea type="text" class="form-control" name="description" id="message"></textarea>
</div>

<input type="hidden" name="enq_account" id="enq_account" value="{{$id_account}}">
<input type="hidden" name="phone_number" id="phone_number" value="{{$mobile_number}}">
<input type="hidden" name="user_info" id="userid" value="{{$user_info}}">
<div class="form-group col-md-3">
<button type="submit" class="btn btn-danger btn-block">Submit</button>
<!-- <a href="#" class="form-control btn btn-danger btn-block">Close</a> -->
</div>

</div>
</form>
</section>
</div>
</div>


