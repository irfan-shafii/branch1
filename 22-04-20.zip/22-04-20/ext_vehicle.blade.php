
<header class="panel-heading wht-bg">
   <h4 class="gen-case"> Vehicle History
	<a href="#"  class="btn btn-info pull-right">
        Campaign Id - Details
    </a>
   </h4>
</header>


<div class="row">

<div class="col-lg-9">
<section class="panel">

<div class="prf-box">
<h3 class="prf-border-head">
Vehicles
</h3>
</header>
<ul class="nav nav-pills" id="vehicle_history_list">
</ul>

</div>

</section>
</div>

<div class="col-lg-3">
<section class="panel">
<div class="panel-body">


	    <form action="#" class="pull-right mail-src-position">
        <div class="input-append">
            <input type="text" class="form-control " placeholder="Search...">
        </div>
    </form>

</div>
</section>
</div>

</div>


<div class="row">
<div class="col-lg-12">

<section class="panel">
<header class="panel-heading">
Vehicle Service History
</header>
<div class="panel-body">
<table class="table table-striped">
<thead>
<tr>
<th>Code</th>
<th>Date</th>
<th>Mileage</th>
<th>Details</th>
<th>WIP</th>
<th>Account</th>
<th>Value</th>
<th>Invoice</th>
<th>Branch</th>
</tr>
</thead>
<tbody id="historyHTML">
<tr>
	<td>SER</td>
	<td>01/09/19</td>
	<td>93767</td>
	<td>13/ALL Routine Service</td>
	<td>21099</td>
	<td>y8010211</td>
	<td>14</td>
	<td>1235432</td>
	<td>S23</td>
</tr>
<tr>
	<td>SER</td>
	<td>01/09/19</td>
	<td>93767</td>
	<td>13/ALL Routine Service</td>
	<td>21099</td>
	<td>y8010211</td>
	<td>14</td>
	<td>1235432</td>
	<td>S23</td>
</tr>
<tr>
	<td>SER</td>
	<td>01/09/19</td>
	<td>93767</td>
	<td>13/ALL Routine Service</td>
	<td>21099</td>
	<td>y8010211</td>
	<td>14</td>
	<td>1235432</td>
	<td>S23</td>
</tr>
</tbody>
</table>
</div>
</section>
</div>
</div>


<div class="row">
<div class="col-lg-12">

<section class="panel">
<div class="prf-box">
        <h3 class="prf-border-head">All Vehicle Purchase History</h3>                 
<form action="#" method="post">
{{csrf_field()}}
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Showroom</label>
<input type="text" class="form-control" name="vehicleinfo1" id="vehicleinfo1" value="" placeholder="Enter Vehicle Showroom">
</div>

<div class="form-group col-md-6">
<label for="exampleInputEmail1">Salesman</label>
<input type="text" class="form-control" name="vehmodel1" id="vehmodel1" value="" placeholder="Enter Vehicle Salesman">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Vehicle Registration Number</label>
<input type="text" class="form-control" name="vehyear1" id="vehyear1" value="" placeholder="Enter Vehicle Registration">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Description of Car</label>
<input type="text" class="form-control" name="vehsalesman1" id="vehsalesman1" value="" placeholder="Enter Vehicle Description">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Available Vehicle : Brand Model</label>
<input type="text" class="form-control" name="vehshowroom1" id="vehshowroom1" value="" placeholder="Enter Vehicle Brand">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Date of Vehicle Invoiced</label>
<input type="text" class="form-control" name="plateno1" id="plateno1" value="" placeholder="Enter Vehicle Invoiced">
</div>
<input type="hidden" name="vehid_account1" id="vehid_account1" value="{{$id_account}}">
<input type="hidden" name="vehicle_id1" id="vehicle_id1" value="0">
<input type="hidden" name="phone_number1" id="phone_number1" value="{{$mobile_number}}">
<input type="hidden" name="user_info1" id="userid1" value="{{$user_info}}">

</form>
</div>
</section>
</div>
</div>

<div class="row">
<div class="col-lg-8">
	
<section class="panel">
<div class="prf-box">
        <h3 class="prf-border-head">Service Reminder</h3>                 
<form action="#" method="post">
{{csrf_field()}}
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Last Service</label>
<input type="text" class="form-control" name="vehicleinfo1" id="vehicleinfo1" value="" placeholder="Enter Last Service">
</div>

<div class="form-group col-md-6">
<label for="exampleInputEmail1">Next Service Date</label>
<input type="text" class="form-control" name="vehmodel1" id="vehmodel1" value="" placeholder="Enter Vehicle Next Service">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Date Last Work</label>
<input type="text" class="form-control" name="vehyear1" id="vehyear1" value="" placeholder="Enter Vehicle Last Work">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Service Contract #</label>
<input type="text" class="form-control" name="vehsalesman1" id="vehsalesman1" value="" placeholder="Enter Service Contract">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Timing Belt Mileage</label>
<input type="text" class="form-control" name="vehshowroom1" id="vehshowroom1" value="" placeholder="Enter Timing Belt Mileage">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Last MOT Date</label>
<input type="text" class="form-control" name="plateno1" id="plateno1" value="" placeholder="Enter Vehicle Last MOT Date">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">MOT Due</label>
<input type="text" class="form-control" name="plateno1" id="plateno1" value="" placeholder="Enter MOT Due">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Return Parts</label>
<input type="text" class="form-control" name="plateno1" id="plateno1" value="" placeholder="Enter Vehicle Plate Number">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Next Emission Check</label>
<input type="text" class="form-control" name="plateno1" id="plateno1" value="" placeholder="Enter Vehicle Return Parts">
</div>
<div class="form-group col-md-6">
<label for="exampleInputEmail1">Emissions</label>
<input type="text" class="form-control" name="plateno1" id="plateno1" value="" placeholder="Enter Emissions">
</div>
<input type="hidden" name="vehid_account1" id="vehid_account1" value="{{$id_account}}">
<input type="hidden" name="vehicle_id1" id="vehicle_id1" value="0">
<input type="hidden" name="phone_number1" id="phone_number1" value="{{$mobile_number}}">
<input type="hidden" name="user_info1" id="userid1" value="{{$user_info}}">

</form>
</div>
</section>
</div>



<div class="col-lg-4">


@if(count($upscales) > 0)
<!--carousel start-->
<section class="panel">

<div class="prf-box">
        <h3 class="prf-border-head">VEHICLE RELATED OFFER</h3> 
<div id="c-slide" class="carousel slide panel-body" data-ride="carousel">
<ol class="carousel-indicators out">
<?php for($i=0; $i<count($upscales); $i++ ) {
if($i == '0'){
$rowclass = 'active';
}
else{
$rowclass = '';
} ?>
<li class="{{$rowclass}}" data-slide-to="{{$i}}" data-target="#c-slide"></li>
<?php } $rowcount=0; ?>
</ol>
<div class="carousel-inner">
@foreach($upscales as $upscale)
<?php
if($rowcount == '0'){
$rowclass1 = 'active';
}
else{
$rowclass1 = '';
} ?>
<div class="item text-center {{$rowclass1}}">
<h3 style="color: #fa8564;">{{$upscale->topic}}</h3>
<p style="color: #95b75d;">{{$upscale->description}}</p>
</div>
<?php $rowcount++; ?>
@endforeach
</div>
<a data-slide="prev" href="{{asset('/bucket')}}/#c-slide" class="left carousel-control">
<i class="fa fa-angle-left"></i>
</a>
<a data-slide="next" href="{{asset('/bucket')}}/#c-slide" class="right carousel-control">
<i class="fa fa-angle-right"></i>
</a>
</div>
</div>
</section>
<!--carousel end-->
@endif
</div>


</div>