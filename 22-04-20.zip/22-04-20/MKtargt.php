<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MKtargt extends Model
{
	protected $connection = 'mysql3';
    protected  $table="mk_00_targt";
}
