<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MKvehic extends Model
{
	protected $connection = 'mysql3';
    protected  $table="mk_00_vehic";
}
