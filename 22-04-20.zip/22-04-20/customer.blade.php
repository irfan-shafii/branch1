<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from bucketadmin.themebucket.net/horizontal_menu.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Nov 2019 10:10:42 GMT -->
<head>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="ThemeBucket">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="shortcut icon" href="{{asset('/bucket')}}/images/favicon.html">

    <title>Customer Info page</title>


@include('layouts.css')

<style type="text/css">
  .form-control{
    color: #4c4a4a !important;
  }

a.ex2:hover, a.ex2:active {font-size: 150%;}

</style>

</head>

  <body class="full-width">

  <section id="container" class="hr-menu">
      <!--header start-->
      <header class="header fixed-top">
          <div class="navbar-header">
              <button type="button" class="navbar-toggle hr-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                  <span class="fa fa-bars"></span>
              </button>

              <!--logo start-->
              <!--logo start-->
              <div class="brand ">
                  <a href="#" class="logo">
                      <img src="http://subscriber.clgnote.in/assets/img/logo-full.png" alt="">
                  </a>
              </div>
              <!--logo end-->
              <!--logo end-->
              <div class="horizontal-menu navbar-collapse collapse ">

              </div>
              <div class="top-nav hr-top-nav">
              </div>

          </div>

      </header>
      <!--header end-->
      <!--sidebar start-->

      <!--sidebar end-->
<!--main content start-->
<section id="main-content">
<section class="wrapper">

            <!--tab nav start-->
            <section class="panel">
                <header class="panel-heading tab-bg-dark-navy-blue">
                    <ul class="nav nav-tabs">
                        <li class="active">
                            <a data-toggle="tab" href="#customer-info">
                                <i class="fa fa-home"></i>
                                Customer &amp; Vehicle Informations
                            </a>
                        </li>
                        <li>
                            <a data-toggle="tab" href="#vehicle-info">
                                <i class="fa fa-gears"></i>
                                Vehicle Details
                            </a>
                        </li>
                        <li>
                            <a data-toggle="tab" href="#contact-info">
                                <i class="fa fa-envelope-o"></i>
                                Contact Informations - Email &amp; SMS
                            </a>
                        </li>
                    </ul>
                </header>
                <div class="panel-body">
	                    <div class="tab-content">
	                    <div id="customer-info" class="tab-pane active">
      						@include('ext_customer')
                        </div>
                        <div id="vehicle-info" class="tab-pane ">
                        @include('ext_vehicle')
                    	</div>
                        <div id="contact-info" class="tab-pane ">
                        @include('ext_contact')
                    	</div>
                    </div>
                </div>
            </section>
            <!--tab nav end-->



<div class="row">
<div class="col-lg-12">

<section class="panel">
<header class="panel-heading">
Enquiries List
</header>
<div class="panel-body">
<table class="table table-striped">
<thead>
<tr>
<th>#</th>
<th>Agent ID</th>
<th>Type</th>
<th>Date</th>
<th>Category</th>
<th>Sub Category</th>
<th>Description</th>
</tr>
</thead>
<tbody id="enqHTML">
</tbody>
</table>
</div>
</section>
</div>
</div>


      <!--footer start-->
      <footer class="footer-section">
          <div class="text-center">
              2019 &copy; Centrixplus
          </div>
      </footer>
      <!--footer end-->
  </section>
</section>

  <!-- Placed js at the end of the document so the pages load faster -->

@include('layouts.script')
  <script type="text/javascript">


    function searchph(ele) {
        var phone = ele.value;
//alert(phone);
  var user = document.getElementById("userid").value;
    if(event.key === 'Enter') {
        //alert(ele.value);    
        if (phone.length == '8') {
            window.location = "{{url('/')}}/customer/"+phone+"/"+user;
        }
        else{
            alert('Mobile Number Must Be 8 Digits');
        }

    }
	}


  function customerinfo(cusid) {
  //alert(cusid);
  $(".acclist").removeClass("active");
  $("#acclist"+cusid).addClass("active");
  $("#fname").val("");
  $("#lname").val("");
  $("#mobile2").val("");
  $("#gender").val("");
  $("#civilid").val("");
  $("#address").val("");
  $("#id_account").val(0);
  $("#enq_account").val(0);
  $("#vehid_account").val(0);
  $("#enqHTML").html("");


  $("#vehicleinfo").val("");
  $("#vehmodel").val("");
  $("#vehyear").val("");
  $("#vehcolor").val("");
  $("#vehshowroom").val("");
  $("#plateno").val("");
  $("#lastservice").val("");
  $("#nextservice").val("");
  $("#vehicle_id").val(0);

  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/customerinfo')}}",
    data: {cusid: cusid}, 
    dataType:'JSON', 
    success: function(data){

          //alert(data.vehicles);
          $("#enqHTML").html(data.enqHTML);

          //var vehicles = data.vehicles;

          //var len =  vehicles.length; 

          $("#vehicle_list").html("");
          $('#vehicle_history_list').html("");
          $('#vehicle_contact_list').html("");

          $('#vehicle_list').html(data.divHtml);
          $('#vehicle_history_list').html(data.divHtml1);
          $('#vehicle_contact_list').html(data.divHtml2);

          $("#fname").val(data.fname);
          $("#lname").val(data.lname);
          $("#mobile2").val(data.mobile2);
          $("#gender").val(data.gender);
          $("#civilid").val(data.civilid);
          $("#address").val(data.address);
          $("#id_account").val(cusid);
          $("#vehid_account").val(cusid);
          $("#enq_account").val(cusid);

        },error:function(){ 
            alert("error!!!!");
        }
  });
  }


  function vehicleinfo(vehid) {
  //alert(vehid);
  //alert(cusid);
  $(".vcclist").removeClass("active");
  $("#vcclist"+vehid).addClass("active");

  $(".vcc1list").removeClass("active");
  $("#vcc1list"+vehid).addClass("active");

  $(".vcc2list").removeClass("active");
  $("#vcc2list"+vehid).addClass("active");

  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/vehicleinfo')}}",
    data: {vehid: vehid}, 
    dataType:'JSON', 
    success: function(data){

          $("#vehicleinfo").val(data.vehicleinfo);
          $("#vehmodel").val(data.vehmodel);
          $("#vehyear").val(data.vehyear);
          $("#vehcolor").val(data.vehcolor);
          $("#vehshowroom").val(data.vehshowroom);
          $("#plateno").val(data.plateno);
		  $("#lastservice").val(data.lastservice);
		  $("#nextservice").val(data.nextservice);
          $("#vehicle_id").val(vehid);


        },error:function(){ 
            alert("error!!!!");
        }
  });
  }

  function getcategory(id) {
    idvalue = id.value;
    //alert(idvalue);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getcategory')}}",
    data: {idvalue: idvalue}, 
    dataType:'JSON', 
    success: function(data){
            //alert(data.categorytype);

        var categorytype = data.categorytype;
        var subvalue = data.subvalue;


          $("#salesman").val("");
          $("#appointment").val("");
          $("#interest").val("");
          $("#appointmenttype").val("");
          $("#agentname").val("");
          $("#showroom").val("");
          $("#advisorname").val("");
          $("#appointmenttype").val("");
          $("#appointmenttype").val("");
          $("#subtype1").hide();
          $("#subtype2").hide();
          $("#agentDiv").hide("");
          $("#appointmentDiv").hide("");
        //alert(categorytype);
        if(categorytype == '1'){
          $("#subdiv2").hide();
          $("#subdiv3").hide();
          $("#subcatdiv1").html("");
          $("#subcatdiv2").html("");
          $("#subcatdiv3").html("");
          $("#subcategory2").val("");
          $("#subcategory3").val("");
        if (data.divhtml != "") {

          $("#subdiv1").show();
          $("#subcatdiv1").html(data.divhtml);
        }
        }

        if(categorytype == '2'){
          $("#subdiv3").hide();
          $("#subcatdiv2").html("");
          $("#subcatdiv3").html("");
          $("#subcategory3").val("");
        if (data.divhtml != "") {

          $("#subdiv2").show();
          $("#subcatdiv2").html(data.divhtml);
        }
        }

        if(categorytype == '3'){
          $("#subcatdiv3").html("");
        if (data.divhtml != "") {

          $("#subdiv3").show();
          $("#subcatdiv3").html(data.divhtml);
        }
        }

        if(categorytype == '4'){
        if(subvalue == '1'){
          $("#appointmentDiv").show("");
          $("#agentDiv").show("");
        if(idvalue == '15' || idvalue == '19' ){
          $("#subtype1").show();
          $("#subtype2").hide();
        }
        else{
          $("#subtype1").hide();
          $("#subtype2").show();         
        }
        }
        }


        },error:function(){ 
            alert("error!!!!");
        }
  });
  }


  function getnextquestion() {
  var questionid = document.getElementById("questionid").value;
  var answer = document.getElementById("answer").value;
  var description = document.getElementById("description").value;
  var mobile = document.getElementById("phone_number").value;
  var user = document.getElementById("userid").value;
  var ctime = document.getElementById("current_time").value;
    //alert(questionid +"-"+ctime);
        $('#nextbtn').attr("disabled", true);
  $.ajax({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    type: "POST",
    url: "{{url('/getquestion')}}",
    data: {questionid: questionid,answer: answer,description: description,mobile: mobile,user: user,ctime: ctime}, 
    dataType:'JSON', 
    success: function(response){
        //alert(response.previous);
        //alert(response.quesid);
        if(response.quesid != '0'){
        $("#questionid").val(0);
        $("#questionid").val(response.quesid);
        $("#questionDIV").html("");
        $("#questionDIV").html(response.question);
        $("#answerDIV").html("");
        $("#answerDIV").html(response.answer);
        $("#desDIV").html("");
        $("#desDIV").html(response.description);
        $("#prev_answers").html("");
        $("#prev_answers").html(response.previous);
        $('#nextbtn').attr("disabled", false);
        if(response.quesid == '18'){
        $('#nextbtn').val("Finish");
        }
        }
        else{
        $('#nextbtn').hide();
        $("#questionid").val(0);
        $("#questionbox").html("");
        $("#prev_answers").html("");
        $("#prev_answers").html(response.previous);
        }
      
    }
  });
  }


  function search() {

  var user = document.getElementById("userid").value;
  var phone = document.getElementById("phsearch").value;
        //alert(phone);    
        if (phone.length == '8') {
            window.location = "{{url('/')}}/customer/"+phone+"/"+user;
        }
        else{
            alert('Mobile Number Must Be 8 Digits');
        }
  }

  </script>

  </body>

<!-- Mirrored from bucketadmin.themebucket.net/horizontal_menu.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Nov 2019 10:10:44 GMT -->
</html>