<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\VicidialLog;
use App\VicidialCloserLog;
use App\VicidialDialLog;
use App\VicidialList;
use App\VicidialLists;
use App\VicidialCampaign;
use Illuminate\Support\Facades\Input; //header
use Excel;
use App\MKtargt;
use App\MKhisty;
use App\MKvlink;
use App\MKvehic;


class ReportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index(Request $request)
    {
        $current_date = date('Y-m-d');
        //$current_date = '2019-11-17';
        $day = date('d');
        $month = date('m');
        $year = date('Y');
        $phone = '';
        if(!empty($request->day)){
            $day = $request->day;
            $month = $request->month;
            $year = $request->year;
        }
            $fromdate = $year. '-' . $month. '-' . $day;
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));
        $outbound = VicidialLog::whereBetween('call_date',[$fromdate, $todate1])->get();
        $inbound = VicidialCloserLog::whereBetween('call_date',[$fromdate, $todate1])->where('status','!=','DROP')->get();
        $missed = VicidialCloserLog::whereBetween('call_date',[$fromdate, $todate1])->where('status','=','DROP')->get();
        if(!empty($request->phone)){
            $phone = $request->phone;
            $inbound = $inbound->where('phone_number',$phone);
            $outbound = $outbound->where('phone_number',$phone);
            $missed = $missed->where('phone_number',$phone);
        }
        $inbound_count = $inbound->count();
        $outbound_count = $outbound->count();
        $missed_count = $missed->count();
        //print_r($inbound_count.'-'.$outbound_count.'-'.$missed_count); exit();
        return view('dashboard',compact('inbound_count','outbound_count','missed_count','year','month','day'));
    }


    public function customerold($mobile,$user)
    {
        
        //$upscales = DB::table('vehicle_upscales')->get();

        $user_info = $user;
        $mobile_number = $mobile;
        $account = DB::table('account')->where('mobile_number',$mobile)->get();
        if(count($account)>0){
            $id_account = $account[0]->id_account;
            $fname = $account[0]->first_name;
            $lname = $account[0]->last_name;
            $mobile2 = $account[0]->alternate_mobile;
            $gender = $account[0]->gender;
            $civilid = $account[0]->civil_id;
            $address = $account[0]->address;
        }
        else{
            $id_account = 0;
            $fname = '';
            $lname = '';
            $mobile2 ='';
            $gender = '';
            $civilid = '';
            $address ='';

        }
        $question = DB::table('csi_questions')->join('csi_answers','csi_questions.id', '=','csi_answers.question_id')->select('csi_questions.*', 'csi_answers.answer', 'csi_answers.description')->where('csi_questions.parent_id','0')->get();

        $vehicles = DB::table('vehicles')->where('phone_number',$mobile_number)->get();
        if(count($vehicles) > 0){
        $upscales = DB::table('vehicles')->join('vehicle_upscales','vehicles.vehicle_brand', '=','vehicle_upscales.brand')->select('vehicle_upscales.*', 'vehicles.phone_number')->where('vehicles.phone_number',$mobile)->get();
        }
        else{
        $upscales = DB::table('vehicle_upscales')->get();
        }

        $enquiry_categories = DB::table('enquiry_categories')->where('parent_id','0')->orderBy('id_enquiry_category','asc')->get();
         $sub_categories1 = DB::table('enquiry_categories')->where('parent_id','1')->orderBy('id_enquiry_category','asc')->get();
         $sub_categories2 = DB::table('enquiry_categories')->where('parent_id','2')->orderBy('id_enquiry_category','asc')->get();
         $sub_categories3 = DB::table('enquiry_categories')->where('parent_id','3')->orderBy('id_enquiry_category','asc')->get();
        $account_comments = DB::table('opportunity')->where('id_account',$id_account)->orderBy('id_opp','desc')->get();
        //print_r($upscales); exit();
        return view('customer_old',compact('upscales','account','account_comments','enquiry_categories','vehicles','sub_categories1','sub_categories2','sub_categories3','question','user_info','mobile_number','fname','lname','id_account','mobile','mobile2','gender','civilid','address'));
    }



    public function customeruser($mobile,$user,$cusid=0)
    {
        
        //print_r($cusid); exit();

        $user_info = $user;
        $mobile_number = $mobile;

        $mktargt = MKtargt::select('MAGIC','FIRSTNAM','SURNAME','PHONE002','PHONE004','ADDRESS','ADDRESS001','ADDRESS002','ADDRESS003','ADDRESS004')->where('PHONE004',$mobile)->get();

        // $mkvehic = MKvehic::select('MAGIC','REGNO','MODELVAR','MODEL','MILEAGE','MOTDATE','LASTSERV','LASTWORK')->join('mk_00_vlink','mk_00_vehic.MAGIC', '=','mk_00_vlink.VEHMAGIC')->addSelect('mk_00_vlink.CTMAGIC as ctmagic')->where('mk_00_vlink.CTMAGIC','231272')->get();
        //  print_r($mkvehic); exit();


        $account = DB::table('account')->where('mobile_number',$mobile)->get();
            $id_account = 0;
            $fname = '';
            $lname = '';
            $mobile2 ='';
            $gender = '';
            $civilid = '';
            $address ='';

        $upscales = DB::table('vehicle_upscales')->get();

        $enquiry_categories = DB::table('enquiry_categories')->where('parent_id','0')->orderBy('id_enquiry_category','asc')->get();

        return view('customer',compact('upscales','mktargt','account','user_info','enquiry_categories','mobile_number','fname','lname','id_account','mobile','mobile2','gender','civilid','address'));
    }


    public function getquestion(Request $request)
    {
        if(isset($_POST['questionid']) && !empty($_POST['questionid'])) {
            $questionid = $_POST['questionid'];
            $answer = $_POST['answer'];
            $description = $_POST['description'];
            $mobile = $_POST['mobile'];
            $user = $_POST['user'];
            $ctime = $_POST['ctime'];
            $question = DB::table('csi_questions')->where('id',$questionid)->get();
        DB::table('user_answers')->insert(['questionid'=>$questionid,'answer'=>$answer,'description'=>$description,'phone_number'=>$mobile,'user'=>$user,'date_time'=>$ctime ]);

        $vehicles = DB::table('vehicles')->where('phone_number',$mobile)->get();

            $questionchild = DB::table('csi_questions')->where('id',$questionid)->where('child_id','>','0')->get();
            $description="";

            if(count($questionchild) > 0){
            $nextquestion = DB::table('csi_questions')->where('id',$question[0]->child_id)->get();
            $nxtques = $nextquestion[0]->question;
            $nxtquesid = $nextquestion[0]->id;
            $nextanswer = DB::table('csi_answers')->where('question_id',$nextquestion[0]->id)->get();
            $nextans = $nextanswer[0]->answer;
            $description=$nextanswer[0]->description;
            $questiontxt  = $nxtques;
            }

            else{
            $nextquestion = DB::table('csi_questions')->where('parent_id',$questionid)->where('answer',$answer)->get();
            if(count($nextquestion) > 0){
            $nxtques = $nextquestion[0]->question;
            $nxtquesid = $nextquestion[0]->id;
            $nextanswer = DB::table('csi_answers')->where('question_id',$nextquestion[0]->id)->get();
            $nextans = $nextanswer[0]->answer;
            $description=$nextanswer[0]->description;
            $questiontxt  = $nxtques;
            }
            else{               
            $nextans = '';
            $description='';
            $questiontxt  = '';
            $nxtquesid  = '0';
            }
            }

            $vehicle_det = ["<BRAND>", "<MODEL>", "<DEALER>", "<TOWN>", "<YEAR>"];
            $vehicle_val   = [$vehicles[0]->vehicle_brand,$vehicles[0]->vehicle_model,$vehicles[0]->dealer,$vehicles[0]->town,$vehicles[0]->vehicle_model_year];

            $nxtques = str_replace($vehicle_det, $vehicle_val, $questiontxt);

            if(empty($description)){               
            $description='<input type="hidden" id="description" name="description" value="">'; 
            }

            $prev_answers = DB::table('user_answers')->where('phone_number',$mobile)->where('date_time',$ctime)->orderBy('id','asc')->get();
            $previous_content = "";
            foreach ($prev_answers as $prev) {      

            $prev_ques = DB::table('csi_questions')->where('id',$prev->questionid)->get();
            $prevques  = $prev_ques[0]->question;
            $prevquestion = str_replace($vehicle_det, $vehicle_val, $prevques);
            $previous_content .= "<li>".$prevquestion."<ul><li>".$prev->answer."</li></ul></li>";

            }


        echo json_encode(array("question"=>$nxtques,"quesid"=>$nxtquesid,"answer"=>$nextans,"description"=>$description,"previous"=>$previous_content));
        }

    }

    public function customer_new()
    {
       // echo $mobile;
        if (isset($_GET["mobile"]) && isset($_GET["user"])) {
            $mobile=$_GET["mobile"];
            $user=$_GET["user"];
        return redirect('/customer/'.$mobile.'/'.$user);
        }
        else if (isset($_GET["mobile"])) {
            $mobile=$_GET["mobile"];
        return redirect('/customer/'.$mobile);
        }// echo $mobile;

        $upscales = DB::table('vehicle_upscales')->get();
        $enquiry_categories = DB::table('enquiry_categories')->where('parent_id','0')->orderBy('id_enquiry_category','asc')->get();
         $sub_categories1 = DB::table('enquiry_categories')->where('parent_id','1')->orderBy('id_enquiry_category','asc')->get();
         $sub_categories2 = DB::table('enquiry_categories')->where('parent_id','2')->orderBy('id_enquiry_category','asc')->get();
         $sub_categories3 = DB::table('enquiry_categories')->where('parent_id','3')->orderBy('id_enquiry_category','asc')->get();
        return view('customer',compact('upscales','enquiry_categories','sub_categories1','sub_categories2','sub_categories3'));
    }

    public function inquiries(Request $request)
    {
       // echo $mobile;

            $fromdate = date("Y-m-d");

        //print_r($mobiles); exit();
        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));
            
        $inquiries = DB::table('opportunity')->orderBy('id_opp','desc')->get();
    

        return view('inquiries',compact('inquiries','fromdate'));
    }

    public function appointments(Request $request)
    {
       // echo $mobile;

            $fromdate = date("Y-m-d");

        //print_r($mobiles); exit();
        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));
            
        $appointments = DB::table('appointments')->whereBetween('appointment_date',[$fromdate, $todate1])->orderBy('id','desc')->get();
    

        return view('appointments',compact('appointments','fromdate'));
    }


    public function vuseranswers($id)
    {
       // echo $mobile;


        $answer = DB::table('user_answers')->where('id',$id)->get();

        $questions = DB::table('csi_questions')->join('user_answers','csi_questions.id', '=','user_answers.questionid')->select('user_answers.*', 'csi_questions.question as qname')->where('user_answers.date_time',$answer[0]->date_time)->orderBy('csi_questions.id','asc')->get(); 
        $vehicles = DB::table('vehicles')->where('phone_number',$questions[0]->phone_number)->get();

        return view('viewanswers',compact('questions','vehicles'));
    }

    public function useranswers(Request $request)
    {
            $phone = '';

            $fromdate = date("Y-m-d");

        //print_r($mobiles); exit();
        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($fromdate)));

        //print_r($mobiles); exit();
        if(!empty($request->phone) && empty($request->fromdate)){
            $phone = $request->phone;
            
        $mobiles = DB::table('user_answers')->where('phone_number',$phone)->select(DB::raw('count(*) as datecount, date_time'))->groupBy('date_time')->get();
        }
        elseif(!empty($request->phone) && !empty($request->fromdate)){
            $phone = $request->phone;
            
        $mobiles = DB::table('user_answers')->where('phone_number',$phone)->whereBetween('user_answers.date_time',[$fromdate, $todate1])->select(DB::raw('count(*) as datecount, date_time'))->groupBy('date_time')->get();
        }
        elseif(empty($request->phone) && !empty($request->fromdate)){
            $phone = $request->phone;
            
        $mobiles = DB::table('user_answers')->whereBetween('user_answers.date_time',[$fromdate, $todate1])->select(DB::raw('count(*) as datecount, date_time'))->groupBy('date_time')->get();
        }
        else{
            
        $mobiles = DB::table('user_answers')->select(DB::raw('count(*) as datecount, date_time'))->groupBy('date_time')->get();
        }
        //print_r($questions); exit();
        return view('useranswers',compact('mobiles','phone','fromdate'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function auto_dial()
    {
        $lists = VicidialLists::select('list_id','list_name','campaign_id')->get();
        //print_r($lists); exit();
        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->get();
        
        // print_r($inbounds); exit();
        return view('auto_dial',compact('lists','campaigns'));
    }

    public function upload(Request $request)
    {

        //print_r($request->all()); exit();
        $path = $request->file('import_file')->getRealPath();

        $data = Excel::load($path)->get();
        
        $headerRow = $data->first()->keys()->toArray();

        if($data->count()){

            $rec_count = 0;

            foreach ($data as $key => $value) {

                    //print_r($value->mobile);

            $lists = VicidialList::insert(['phone_number' => $value->mobile,'first_name' => $value->name,'list_id' => $request->listid,'entry_date' => date("Y-m-d H:i:s"),'status'=>'NEW','called_since_last_reset'=>'N']);

            $rec_count++;

               // print_r($data);
            }
            $alert = $rec_count." Records Added Successfully";
            //exit();
        }
        return redirect('/auto-dial')->with('alert', $alert);

    }


    public function auto_upload()
    {
        $lists = VicidialLists::select('list_id','list_name','campaign_id')->get();
        //print_r($lists); exit();
        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->get();
        

        $folder = DB::table('cron_folder')->where('delete_status','0')->first();
        
        // print_r($inbounds); exit();
        return view('autoupload_dial',compact('lists','campaigns','folder'));
    }

    public function autodial_folder(Request $request)
    {
        DB::table('cron_folder')->update(['delete_status' => '1']);
        DB::table('cron_folder')->insert(['location' => $request->directory]);
        return redirect('/autoupload-dial');
    }
    public function autodial_upload(Request $request)
    {

        //print_r($request->all()); exit();
        //$path = 'public/auto_dial/auto_dial.csv';


        $path = $request->file('import_file')->getRealPath();

        $data = Excel::load($path)->get();
        
        $headerRow = $data->first()->keys()->toArray();

        if($data->count()){

            $rec_count = 0;

            foreach ($data as $key => $value) {

                    //print_r($value->mobile);

            $lists = DB::table('cron_autodial')->insert(['phone_number' => $value->mobile,'first_name' => $value->name,'listid' => $request->listid,'campaignid' => $request->campaignid,'entry_datetime' => $request->entry_date]);

            $rec_count++;

                // /print_r($data);
            }
            $alert = $rec_count." Records Added Successfully";
            //exit();
        }

        $product_img = Input::file('import_file');
  
        //print_r($destinationPath1); exit();
        if($product_img)
         {
  
              $destinationPath1 = $_SERVER['DOCUMENT_ROOT'].'/alghanim/public/auto_dial';           
              $timestamp1 = str_replace([' ', ':'], '-', date("YmdHis"));
              $namefile1 = $product_img->getClientOriginalName();    
              $recfilename1 = preg_replace('/\s+/', '', $namefile1);
              $recfilename1 = $timestamp1."_123_".$recfilename1;
              $upload_success1 = Input::file('import_file')->move($destinationPath1, $recfilename1);
              $certificatePath1 = ('http://'.$_SERVER['HTTP_HOST']."/alghanim/public/auto_dial/".$recfilename1);

         }

        return redirect('/autoupload-dial')->with('alert', $alert);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //print_r($request->all()); exit();
        $id_account = $request->id_account;
        if($id_account == 0){
        $id_account= DB::table('account')->insertGetId(['first_name'=>$request->fname,'last_name'=>$request->lname,'mobile_number'=>$request->mobile,'alternate_mobile'=>$request->mobile2,'civil_id'=>$request->civilid,'id_user'=>$request->user_info,'gender'=>$request->gender,'address'=>$request->address,'date_add'=>date("Y-m-d H:i:s"),'date_update'=>date("Y-m-d H:i:s")]);
        }
        else{

        DB::table('account')->where('id_account',$id_account)->update(['first_name'=>$request->fname,'last_name'=>$request->lname,'mobile_number'=>$request->mobile,'alternate_mobile'=>$request->mobile2,'civil_id'=>$request->civilid,'id_user'=>$request->user_info,'gender'=>$request->gender,'address'=>$request->address,'date_update'=>date("Y-m-d H:i:s")]);
        }
        return redirect('/customer/'.$request->mobile.'/'.$request->user_info);
    }

    public function vehstore(Request $request)
    {
        //print_r($request->all()); exit();
        $id_account = $request->vehicle_id;

        if($id_account == 0){

        DB::table('vehicles')->insert(['phone_number'=>$request->phone_number,'id_account'=>$request->vehid_account,'vehicle_type'=>$request->vehicleinfo,'vehicle_model'=>$request->vehmodel,'vehicle_plate_no'=>$request->plateno,'color'=>$request->vehcolor,'vehicle_model_year'=>$request->vehyear,'dealer'=>$request->vehsalesman,'town'=>$request->vehshowroom]);
        }
        else{
        DB::table('vehicles')->where('id',$request->vehicle_id)->update(['phone_number'=>$request->phone_number,'id_account'=>$request->vehid_account,'vehicle_type'=>$request->vehicleinfo,'vehicle_model'=>$request->vehmodel,'vehicle_plate_no'=>$request->plateno,'color'=>$request->vehcolor,'vehicle_model_year'=>$request->vehyear,'dealer'=>$request->vehsalesman,'town'=>$request->vehshowroom]);

        }
        return redirect('/customer/'.$request->phone_number.'/'.$request->user_info);
    }


    public function enqstore(Request $request)
    {
        //print_r($request->all()); exit();
        $id_account = $request->enq_account;

        $iduser = DB::table('account')->where('id_account',$id_account)->first();

        if(!empty($request->category)){
        $category = $request->category;
        $subcategory = '';

        $subcategory = "";
        $subcategory2 = "";
        $subcategory3 ="";

        if(!empty($request->subcategory1)){
        $subcategory = $request->subcategory1;
        }
        if(!empty($request->subcategory2)){
        $subcategory2 = $request->subcategory2;
        }
        if(!empty($request->subcategory3)){
        $subcategory3 = $request->subcategory3;
        }

        $appointment = $request->appointment;
        if(!empty($appointment)){
            $appointment_date = date("Y-m-d",strtotime($appointment));
            $appointment_time = date("H:i:s",strtotime($appointment));
        DB::table('appointments')->insert(['id_account'=>$id_account,'mobile_number'=>$iduser->mobile_number,'appointment_datetime'=>$request->appointment,'appointment_date'=>$appointment_date,'appointment_time'=>$appointment_time,'salesman'=>$request->salesman,'agentname'=>$request->agentname,'showroom'=>$request->showroom,'advisorname'=>$request->advisorname,'interest'=>$request->interest,'appointmenttype'=>$request->appointmenttype,'appointmentcode'=>$request->appointmentcode]);
        }
        else{
            $appointment_date = '';
            $appointment_time = '';
        }


        DB::table('opportunity')->insert(['id_account'=>$id_account,'enquiry_category'=>$request->category,'enquiry_subcategory'=>$subcategory,'enquiry_subcategory2'=>$subcategory2,'enquiry_subcategory3'=>$subcategory3,'description'=>$request->description,'appointment_date'=>$appointment_date,'appointment_time'=>$appointment_time,'id_agent'=>$request->user_info,'first_name'=>$iduser->first_name,'last_name'=>$iduser->last_name,'mobile_number'=>$iduser->mobile_number,'alternate_number'=>$iduser->alternate_mobile,'date_add'=>date("Y-m-d H:i:s"),'date_update'=>date("Y-m-d H:i:s")]);

        DB::table('account_comments')->insert(['id_account'=>$id_account,'description'=>$request->description,'date_add'=>date("Y-m-d H:i:s"),'date_update'=>date("Y-m-d H:i:s")]);
        }
        return redirect('/customer/'.$iduser->mobile_number.'/'.$request->user_info);
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
