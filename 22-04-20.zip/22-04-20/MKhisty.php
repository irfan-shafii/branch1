<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MKhisty extends Model
{
	protected $connection = 'mysql3';
    protected  $table="mk_00_histy";
}
